Nmap-Hydra : Scanning with Nmap & brute-forcing with Hydra.

Steps:
Copy these commands in yout terminal : ->

git clone https://github.com/mansoorr123/Nmap-Hydra.git

Cd Nmap-Hydra/

chmod +x nmap-hydra.sh

./nmap-hydra.sh
